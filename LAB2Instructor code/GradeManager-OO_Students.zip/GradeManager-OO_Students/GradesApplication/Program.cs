﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GradesApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            SchoolView sm = new SchoolView();
            sm.Run();
        }
    }
}

